<template>
  <DashboardChartSkeleton />
</template>
